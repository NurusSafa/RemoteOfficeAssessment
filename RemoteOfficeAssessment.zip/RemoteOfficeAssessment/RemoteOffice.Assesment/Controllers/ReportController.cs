﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RemoteOfficeTest.DTO;
using RemoteOfficeTest.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Talent.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        private readonly ILogger<ReportController> _logger;
        private readonly IReportService _reportService;
        public ReportController(ILogger<ReportController> logger, IReportService reportService)
        {
            _logger = logger;
            _reportService = reportService;

        }

        [HttpGet]
        [Route("GetTest")]
        public IActionResult GetTest()
        {
            return Ok("test");
        }

        [HttpGet]
        [Route("GetReport")]
        public IActionResult GetReport(DateTime startdate,DateTime endDate,string personName ="")
        {
            try
            {
                List<ReportDto> data = _reportService.GetMonthlyProfitsByDateNPerson(startdate, endDate, personName);
                return Ok(data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new ObjectResult(ex);
            }
        }

        [HttpGet]
        [Route("GetAppointments")]
        public IActionResult GetAppointments(DateTime startdate, DateTime endDate ,int practitionerId)
        {
            try
            {
                List<AppointmentDto> data = _reportService.GetAppointmentsByPractitionar(startdate, endDate, practitionerId);
                return Ok(data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new ObjectResult(ex);
            }
        }

    }
}
