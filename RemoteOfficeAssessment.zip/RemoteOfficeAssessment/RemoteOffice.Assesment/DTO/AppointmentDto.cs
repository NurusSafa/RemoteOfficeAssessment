﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RemoteOfficeTest.DTO
{
    public class AppointmentDto
    {
        public int Id { get; set; } 
        public DateTime Date { get; set; }
        public string Client_Name { get; set; }
        public string Appointment_Type { get; set; }
        public int Duration { get; set; }
        public decimal Revenue { get; set; }
        public decimal Cost { get; set; }
        public int Practitioner_Id { get; set; }
        public string PractitionerName { get; set; }
    }
}
