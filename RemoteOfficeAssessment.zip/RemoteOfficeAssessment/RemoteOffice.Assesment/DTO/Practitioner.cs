﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RemoteOfficeTest.DTO
{
    public class PractitionerDto
    {
        public PractitionerDto()
        {
            Appointments = new List<AppointmentDto>();
        }
        public int Id  { get; set; }
        public string Name { get; set; }
        public List<AppointmentDto> Appointments { get; set; }
    }
}
