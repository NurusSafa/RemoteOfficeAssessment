﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RemoteOfficeTest.DTO
{
    public class ReportDto
    {
        public DateTime Date { get; set; }
        public string MonthName { get; set; }      
        public decimal Revenue { get; set; }
        public decimal Cost { get; set; }
        public int PractitionerId { get; set; }
        public string PractitionerName { get; set; }
    }

    public class DateRange
    {
        [Required(ErrorMessage = "Please enter the value")]
        public DateTime[] value { get; set; }

    }
}
