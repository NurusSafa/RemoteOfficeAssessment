﻿using Newtonsoft.Json;
using RemoteOfficeTest.Model;
using RemoteOfficeTest.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RemoteOfficeTest.Services.Implementations
{
    public class DataService
    {
        public IQueryable<Appointment> lstAppointment { get; private set; }
        public IQueryable<Practitioner> lstPractitioner { get; private set; }

        private string DataSourcePath;
        private string AppointmentsFileName;
        private string PractitionerFileName;

        public DataService()
        {
            DataSourcePath = "Data\\";
            AppointmentsFileName = "appointments.json";
            PractitionerFileName = "practitioners.json";
            SetAllAppointments();
            SetAllPractitioners();
        }

        private void SetAllAppointments()
        {
            string fullRoute = DataSourcePath + AppointmentsFileName;
            string myJsonString = System.IO.File.ReadAllText(fullRoute);
            lstAppointment = JsonConvert.DeserializeObject<List<Appointment>>(myJsonString).AsQueryable();
        }

        private void SetAllPractitioners()
        {
            string fullRoute = DataSourcePath + PractitionerFileName;
            string myJsonString = System.IO.File.ReadAllText(fullRoute);
            lstPractitioner = JsonConvert.DeserializeObject<List<Practitioner>>(myJsonString).AsQueryable(); ;
        }
    }
}
