﻿using RemoteOfficeTest.DTO;
using RemoteOfficeTest.Model;
using RemoteOfficeTest.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RemoteOfficeTest.Services.Implementations
{
    public class ReportService : IReportService
    {
        private readonly IQueryable<Appointment> lstAppointment;
        private readonly IQueryable<Practitioner> lstPractitioner;
        private readonly DataService _DataService;
        public ReportService(DataService dataService)
        {
            _DataService = dataService;

            lstAppointment = _DataService.lstAppointment;
            lstPractitioner = _DataService.lstPractitioner;
        }
        public List<ReportDto> GetMonthlyProfits()
        {
            var data = (from practitioner in lstPractitioner.DefaultIfEmpty()
                        join appointment in lstAppointment
                         on practitioner.Id equals appointment.Practitioner_Id
                        group new { practitioner, appointment } by new { practitioner.Id, appointment.Date.Month }
                       into monthlyProfit
                        //from profit in monthlyProfit
                        orderby monthlyProfit.Key.Id, monthlyProfit.Key.Month
                        select new ReportDto
                        {
                            MonthName = GetMonthName(monthlyProfit.FirstOrDefault().appointment.Date.Month),
                            Revenue = monthlyProfit.Sum(v => v.appointment.Revenue),
                            Cost = monthlyProfit.Sum(v => v.appointment.Cost),
                            Date = monthlyProfit.Max(v => v.appointment.Date),
                            PractitionerId = monthlyProfit.Key.Id,
                            PractitionerName = monthlyProfit.FirstOrDefault().practitioner.Name
                        }
                       ).Distinct().ToList();

            return data;
        }
        private string GetMonthName(int monthNumber)
        {
            List<string> lstMonths = new List<string> { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
            string monthName = lstMonths[monthNumber - 1];
            return monthName;
        }      

        public List<ReportDto> GetMonthlyProfitsByDates(DateTime startDate, DateTime endDate)
        {
            var data = (from practitioner in lstPractitioner.DefaultIfEmpty()
                        join appointment in lstAppointment
                        on practitioner.Id equals appointment.Practitioner_Id
                        where appointment.Date.CompareTo(startDate)>=0 && appointment.Date.CompareTo(endDate) <= 0
                        group new { practitioner, appointment } by new { practitioner.Id, appointment.Date.Month }
                      into monthlyProfit
                       orderby monthlyProfit.Key.Id, monthlyProfit.Key.Month
                        select new ReportDto
                        {
                            MonthName = GetMonthName(monthlyProfit.FirstOrDefault().appointment.Date.Month),
                            Revenue = monthlyProfit.Sum(v => v.appointment.Revenue),
                            Cost = monthlyProfit.Sum(v => v.appointment.Cost),
                            Date = monthlyProfit.Max(v => v.appointment.Date),
                            PractitionerId = monthlyProfit.Key.Id,
                            PractitionerName = monthlyProfit.FirstOrDefault().practitioner.Name
                        }
                      ).Distinct().ToList();

            return data;
        }

        public List<ReportDto> GetMonthlyProfitsByDateNPerson(DateTime startDate, DateTime endDate,string name ="")
        {
            var data = (from practitioner in lstPractitioner.DefaultIfEmpty()
                        join appointment in lstAppointment
                        on practitioner.Id equals appointment.Practitioner_Id
                        where !string.IsNullOrEmpty(name)? appointment.Date.CompareTo(startDate) >= 0 && appointment.Date.CompareTo(endDate) <= 0 && practitioner.Name.Contains(name): appointment.Date.CompareTo(startDate) >= 0 && appointment.Date.CompareTo(endDate) <= 0
                        group new { practitioner, appointment } by new { practitioner.Id, appointment.Date.Month }
                      into monthlyProfit
                        orderby monthlyProfit.Key.Id, monthlyProfit.Key.Month
                        select new ReportDto
                        {
                            MonthName = GetMonthName(monthlyProfit.FirstOrDefault().appointment.Date.Month),
                            Revenue = monthlyProfit.Sum(v => v.appointment.Revenue),
                            Cost = monthlyProfit.Sum(v => v.appointment.Cost),
                            Date = monthlyProfit.Max(v => v.appointment.Date),
                            PractitionerId = monthlyProfit.Key.Id,
                            PractitionerName = monthlyProfit.FirstOrDefault().practitioner.Name
                        }
                      ).Distinct().ToList();

            return data;
        }

        public List<AppointmentDto> GetAppointmentsByPractitionar(DateTime startDate, DateTime endDate,int practitionerId)
        {
            var data = (from appointment in lstAppointment 
                        join practitioner  in lstPractitioner
                        on appointment.Practitioner_Id equals practitioner.Id                      
                        where appointment.Practitioner_Id == practitionerId
                        && appointment.Date.CompareTo(startDate) >= 0 && appointment.Date.CompareTo(endDate) <= 0
                        select new AppointmentDto
                        {
                            Appointment_Type = appointment.Appointment_Type,
                            Client_Name = appointment.Client_Name,
                            Cost = appointment.Cost,
                            Date = appointment.Date.Date,
                            Duration = appointment.Duration,
                            Id = appointment.Id,
                            Practitioner_Id = appointment.Practitioner_Id,
                            Revenue = appointment.Revenue,
                            PractitionerName = practitioner.Name

                        }).ToList();                         

            return data;
        }

        public List<string> GetPractitionerNames()
        {
            return lstPractitioner.Select(v => v.Name).ToList();
        }
        private List<AppointmentDto> MapAppointments(List<Appointment> lstAppointmentDMO)
        {
            List<AppointmentDto> appointmentDtos = new List<AppointmentDto>();
            for (int i = 0; i < lstAppointmentDMO.Count; i++)
            {
                appointmentDtos.Add(new AppointmentDto
                {
                    Appointment_Type = lstAppointmentDMO[i].Appointment_Type,
                    Client_Name = lstAppointmentDMO[i].Client_Name,
                    Cost = lstAppointmentDMO[i].Cost,
                    Date = lstAppointmentDMO[i].Date.Date,
                    Duration = lstAppointmentDMO[i].Duration,
                    Id = lstAppointmentDMO[i].Id,
                    Practitioner_Id = lstAppointmentDMO[i].Practitioner_Id,
                    Revenue = lstAppointmentDMO[i].Revenue
                });
            }
            return appointmentDtos;
        }
      
    }
}
