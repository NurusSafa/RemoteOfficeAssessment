﻿using RemoteOfficeTest.DTO;
using RemoteOfficeTest.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RemoteOfficeTest.Services.Interfaces
{
    public interface IReportService
    {
        public List<ReportDto> GetMonthlyProfits();
        public List<ReportDto> GetMonthlyProfitsByDates(DateTime startDate, DateTime endDate);
        public List<AppointmentDto> GetAppointmentsByPractitionar(DateTime startDate, DateTime endDate, int practitionerId);
        public List<ReportDto> GetMonthlyProfitsByDateNPerson(DateTime startDate, DateTime endDate, string name = "");
        public List<string> GetPractitionerNames();


    }
}
