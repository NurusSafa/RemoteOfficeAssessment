﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RemoteOfficeTest.Model
{
    public class Practitioner
    {
        public Practitioner()
        {
            Appointments = new List<Appointment>();
        }
        public int Id { get; set; }
        public string Name { get; set; }

        public virtual ICollection<Appointment> Appointments { get; set; }
    }
}
