﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RemoteOfficeTest.DTO;
using RemoteOfficeTest.Model;
using RemoteOfficeTest.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RemoteOfficeTest.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly IReportService _reportService;

        public IndexModel(ILogger<IndexModel> logger, IReportService reportService)
        {
            _logger = logger;
            _reportService = reportService;
        }

        public void OnGet()
        {
            ViewData["practitionerdata"] = _reportService.GetPractitionerNames();
        }
    }
}
