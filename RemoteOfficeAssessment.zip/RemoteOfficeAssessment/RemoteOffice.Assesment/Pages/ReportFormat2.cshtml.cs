﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using RemoteOfficeTest.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RemoteOfficeTest.Pages
{
    public class ReportFormat2 : PageModel
    {
        private readonly ILogger<ReportFormat2> _logger;
        private readonly IReportService _reportService;

        public ReportFormat2(ILogger<ReportFormat2> logger, IReportService reportService)
        {
            _logger = logger;
            _reportService = reportService;
        }

        public void OnGet()
        {
            ViewData["practitionerdata"] = _reportService.GetPractitionerNames();
        }
    }
}
